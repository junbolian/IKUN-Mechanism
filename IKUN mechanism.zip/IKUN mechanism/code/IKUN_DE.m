function [BestScore, BestPos, cg_curve] = IKUN_DE(nPop, MaxIt, lb, ub, dim, fobj)
% IKUN-DE: Differential-Evolution (+ crowding potential)
% -------------------------------------------------------------------------
% nPop      : population size (µ = λ)
% MaxIt     : #iterations (= generations)
% lb, ub    : 1×dim vectors with search-space bounds
% dim       : #decision variables
% fobj      : handle to objective function  f(x)
% k         : k-NN count used in density estimation          (e.g. 7)
% lambda    : crowding-penalty coefficient                   (e.g. 0.5)
% W         : sliding-window length (generations)            (e.g. 5)
%
% RETURNS
%   BestScore – best f(x) found
%   BestPos   – corresponding solution vector
%   cg_curve  – BestScore vs. iteration (1×MaxIt)
% -------------------------------------------------------------------------

    %% IKUN Parameters
    k = 5; %(3,5,7,10)
    lambda = 0.3; %(0.01,0.1,0.3,0.5,1)
    W = 5;          % Window size (generations kept in memory) (3,4,5)
%% --- DE parameters (same as baseline) ------------------------------
F   = 0.5;          % mutation scaling
pCR = 0.9;          % crossover rate
VarSize = [1 dim];

%% --- Initial population --------------------------------------------------
pop = repmat(struct('Pos',[],'Cost',[],'U',[],'Faug',[]), nPop ,1);
for i = 1:nPop
    pop(i).Pos  = lb + rand(VarSize).*(ub-lb);
    pop(i).Cost = fobj(pop(i).Pos);
end

%% --- Persistent memory for IKUN -----------------------------------------
persistent HistoryPositions KDtree
HistoryPositions = []; KDtree = [];

[U, HistoryPositions, KDtree] = IKUN( ...
        vertcat(pop.Pos) , 1 , W , k , HistoryPositions , KDtree);

for i = 1:nPop
    pop(i).U     = U(i);
    pop(i).Faug  = pop(i).Cost + lambda*pop(i).U;
end

[BestScore , idx] = min([pop.Cost]);
BestPos             = pop(idx).Pos;
cg_curve            = zeros(1, MaxIt);

%% ================= Evolution ============================================
for it = 1:MaxIt

    for i = 1:nPop

        x = pop(i).Pos;

        % ----- Mutation: DE/rand/1 --------------------------------------
        idxs = randperm(nPop);
        idxs(idxs==i) = [];               % exclude current target
        a = idxs(1);  b = idxs(2);  c = idxs(3);

        y = pop(a).Pos + F * (pop(b).Pos - pop(c).Pos);

        % bounds handling
        y = max(min(y , ub) , lb);

        % ----- Crossover -------------------------------------------------
        z = x;
        jRand = randi(dim);
        for j = 1:dim
            if rand <= pCR || j == jRand
                z(j) = y(j);
            end
        end

        % ----- Evaluate trial & crowding potential ----------------------
        trialCost = fobj(z);

        [Utrial, HistoryPositions, KDtree] = IKUN( ...
                       z , it+1 , W , k , HistoryPositions , KDtree);

        Ftrial = trialCost + lambda * Utrial;

        % ----- Selection (crowding-aware) -------------------------------
        if Ftrial <= pop(i).Faug
            pop(i).Pos   = z;
            pop(i).Cost  = trialCost;
            pop(i).U     = Utrial;
            pop(i).Faug  = Ftrial;
        end
    end

    % ----- Best-so-far (true objective) ---------------------------------
    [currBest , idx] = min([pop.Cost]);
    if currBest < BestScore
        BestScore = currBest;
        BestPos   = pop(idx).Pos;
    end
    cg_curve(it) = BestScore;

    % (可选) 每 100 迭代打印一次
    % if mod(it,100)==0
    %     fprintf('Iter %4d | Best = %.4e\n',it,BestScore);
    % end
end
end
