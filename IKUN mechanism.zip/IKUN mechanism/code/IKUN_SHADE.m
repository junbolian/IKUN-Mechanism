function [fitnessBestX, bestX, Convergence_curve] = IKUN_SHADE( ...
        SearchAgents_no, Gmax, lb, ub, dim, fobj)
% IKUN-SHADE  --------------------------------------------------------------
% SHADE + mean-field crowding (IKUN)   —   author: <your-name>
% -------------------------------------------------------------------------
% Inputs are identical to your baseline SHADE, plus:
%   k       : #nearest neighbors for KD-tree density
%   lambda  : crowding-penalty coefficient
%   W       : #generations kept in sliding window
% -------------------------------------------------------------------------

    %% IKUN Parameters
    k = 5; %(3,5,7,10)
    lambda = 0.5; %(0.01,0.1,0.3,0.5,1)
    W = 5;          % Window size (generations kept in memory) (3,4,5)
%% ---------- RANGE VECTORS ------------------------------------------------
if numel(ub)==1,  ub = ub .* ones(1,dim);  end
if numel(lb)==1,  lb = lb .* ones(1,dim);  end

%% ---------- SHADE PARAMETERS --------------------------------------------
H   = SearchAgents_no;                 % memory size
MCR = 0.5 * ones(H,1);                 % CR memory
MF  = 0.5 * ones(H,1);                 % F  memory
A   = [];                              % external archive

%% ---------- INITIAL POPULATION ------------------------------------------
x       = lb + rand(SearchAgents_no,dim).*(ub-lb);
fitness = arrayfun(@(i) fobj(x(i,:)), 1:SearchAgents_no)';

% persistent memory for IKUN
persistent HistoryPositions KDtree
HistoryPositions = []; KDtree = [];

% 初始势能
[U, HistoryPositions, KDtree] = IKUN(x, 1, W, k, HistoryPositions, KDtree);
Faug = fitness + lambda*U;

%% ---------- RECORD BEST --------------------------------------------------
[fitnessBestX , idx] = min(fitness);
bestX                 = x(idx,:);
Convergence_curve     = zeros(1,Gmax);

%% =====================  MAIN LOOP  ======================================
q = 1;                       % index in memory 1…H
for G = 1:Gmax

    SCR = [];  SF = [];  w = [];                  % successful parameter logs
    deltaFit = [];                               % ∆f for weighting memory

    pmin = 2/SearchAgents_no;

    for i = 1:SearchAgents_no

        %% --- 从历史记忆采样 CR, F --------------------------------------
        r  = randi(H);
        CR = min(max(normrnd(MCR(r),0.1),0),1);
        F  = cauchyrnd(MF(r),0.1);   while F<=0,  F=cauchyrnd(MF(r),0.1);  end
        F  = min(F,1);

        %% --- 当前个体 p-best 引导 --------------------------------------
        [~, idxSorted] = sort(fitness);
        p  = unifrnd(pmin,0.2);
        pBest = idxSorted( randi( max(round(p*SearchAgents_no),1) ) );

        %% --- 选择 r1, r2 -------------------------------------------------
        r1 = randi(SearchAgents_no);    while r1==i, r1=randi(SearchAgents_no); end
        S  = [x; A];                    % S = P ∪ Archive
        r2 = randi(size(S,1));
        while r2==i || r2==r1,  r2=randi(size(S,1));  end

        %% --- 变异 (current-to-pbest/1) ----------------------------------
        v = x(i,:) + F*( x(pBest,:) - x(i,:) ) + F*( x(r1,:) - S(r2,:) );

        %% --- 边界修复 ----------------------------------------------------
        v = max(min(v,ub),lb);

        %% --- 二进制交叉 --------------------------------------------------
        u = x(i,:);
        jRand = randi(dim);
        mask  = rand(1,dim)<=CR;  mask(jRand)=true;
        u(mask) = v(mask);

        %% --- 评估 trial 含势能 ------------------------------------------
        fitU = fobj(u);
        [Uu, HistoryPositions, KDtree] = IKUN(u, G+1, W, k, HistoryPositions, KDtree);
        Faug_u = fitU + lambda*Uu;

        %% --- 选择 --------------------------------------------------------
        if Faug_u <= Faug(i)
            A  = [A ; x(i,:)];                          % 加入存档
            x(i,:)=u;    fitness(i)=fitU;  Faug(i)=Faug_u;
            SCR   = [SCR ; CR];
            SF    = [SF  ; F ];
            deltaFit = [deltaFit ; abs(fitU - fitnessBestX)];
        end
    end

    %% --- 限制存档大小 ----------------------------------------------------
    if size(A,1) > SearchAgents_no
        A( randperm(size(A,1), size(A,1)-SearchAgents_no) , : ) = [];
    end

    %% --- 更新记忆矩阵 MCR, MF -------------------------------------------
    if ~isempty(SCR)
        w = deltaFit / sum(deltaFit);
        MCR(q) = sum(w .* SCR);
        MF(q)  = sum(w .* (SF.^2)) / sum(w.*SF);
        q = mod(q, H) + 1;
    end

    %% --- 记录最优 --------------------------------------------------------
    [fitnessBestX , idx] = min(fitness);
    bestX               = x(idx,:);
    Convergence_curve(G)= fitnessBestX;

    % 可选进度输出
    % if mod(G,100)==0
    %     fprintf('Gen %4d | Best %.4e\n', G, fitnessBestX);
    % end
end
end
