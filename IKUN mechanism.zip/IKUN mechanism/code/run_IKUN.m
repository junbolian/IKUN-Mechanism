clc; clear; close all;
warning off

%% ---------------- 基本参数 ----------------
nPop      = 50;          % population size
dim       = 20;          % CEC-2022 only supports 2 / 10 / 20
Max_iter  = (10000*dim)/nPop;
run_times = 1;          % independent trials

AlgorithmList = {'GA','k=3'};
AlgorithmFunc = {@GA,@IKUN_PSO};

% ---------------- 主循环 ----------------
for Function_name = 1:12
    [lb, ub, dim, fobj] = Get_Functions_cec2022(Function_name, dim);
    % 结果容器：1 Name | 2 Curve | 3 BestVal | 4 BestPos
    Optimal_results        = cell(4 , numel(AlgorithmList));
    Optimal_results(1 , :) = AlgorithmList;
    time_record            = zeros(run_times , numel(AlgorithmList));

    for runID = 1:run_times
        for alg = 1:numel(AlgorithmList)
            tic
            [bestScore,bestPos,curve] = AlgorithmFunc{alg}( ...
                                        nPop,Max_iter,lb,ub,dim,fobj);
            time_record(runID,alg) = toc;

            Optimal_results{2,alg}(runID,:) = curve;
            Optimal_results{3,alg}(runID,:) = bestScore;
            Optimal_results{4,alg}(runID,:) = bestPos;

            fprintf('F%02d  run%02d  %-7s  best=%.3e  time=%.2fs\n', ...
                    Function_name,runID,AlgorithmList{alg},bestScore,time_record(runID,alg));
        end
    end

    % ------------- 统计指标 -------------
    [Results,wilcoxon,friedman] = Cal_stats(Optimal_results,time_record);
    avgTime = mean(time_record , 1);   % 1 × Alg

    % ------------- 写 Excel -------------
    fileName = sprintf('cec2022_Results_D%d.xlsx',dim);

    % ---- Sheet 1 : 性能指标 + 平均时间 ----
    rowNames = {'worst';'best';'std';'mean';'time'};
    metrics  = [ Results(3:7,:) ];           % 5 × Alg
    block    = [ rowNames , metrics ];       % 5 × (1+Alg)

    xlswrite(fileName , AlgorithmList , 1 , 'C1');
    firstRow = (Function_name-1)*5 + 2;
    xlswrite(fileName , {['F' num2str(Function_name)]} , 1 , sprintf('A%d',firstRow));
    xlswrite(fileName , block                  , 1 , sprintf('B%d',firstRow));

    % ---- Sheet 2 : Wilcoxon ----
    xlswrite(fileName , AlgorithmList(2:end) , 2 , 'C1');
    wHead = {['F' num2str(Function_name)] ; ''};      % 2 行，与 p-value 行数对齐
    wVal  = num2cell([wilcoxon.signed_p_value ; wilcoxon.ranksum_p_value]);
    wRow  = (Function_name-1)*2 + 2;
    xlswrite(fileName , [wHead , wVal] , 2 , sprintf('A%d',wRow));

    % ---- Sheet 3 : Friedman ----
    xlswrite(fileName , {['F' num2str(Function_name)] , 'Friedman' , friedman} , ...
                        3 , sprintf('A%d',Function_name+1));

    % ---- Sheet 4 : 每次运行时间 ----
    xlswrite(fileName , AlgorithmList , 4 , 'B1');
    tStart = (Function_name-1)*run_times + 2;
    xlswrite(fileName , [[{['F' num2str(Function_name)]} ; cell(run_times-1,1)], ...
        num2cell(time_record)] , 4 , sprintf('A%d',tStart));

    %% 绘图（函数图像与收敛曲线）
    color_mat = hsv(length(AlgorithmList));
    figure('name',['F' num2str(Function_name) ' 函数图像 & 收敛曲线'])
    
    subplot(1,2,1)
    func_plot_cec2022(Function_name,dim)
    colormap(cool)

    subplot(1,2,2)
    for i = 1:length(AlgorithmList)
        semilogy(mean(Optimal_results{2,i}),...
            'LineWidth',1.5,'Color',color_mat(i,:));
        hold on
    end
    title(['Convergence curve, Dim=' num2str(dim)])
    xlabel('Iteration'); ylabel('Best Fitness');
    legend(AlgorithmList); grid on; box on
    saveas(gcf, ['cec2022-F' num2str(Function_name) '收敛图.png']); 
    close(gcf);

    %% 箱线图
    figure('name',['F' num2str(Function_name) ' 箱线图'],'Position',[400 200 300 180])
    boxplot_mat = [];
    for i = 1:length(AlgorithmList)
        boxplot_mat = [boxplot_mat, Optimal_results{3,i}];
    end
    boxplot(boxplot_mat,'Labels',AlgorithmList)
    ylabel('Best Fitness');
    title(['cec2022-F' num2str(Function_name)])
    saveas(gcf, ['cec2022-F' num2str(Function_name) '箱线图.png']);
    close(gcf);
end
