clc; clear; close all;
warning off

%% ---------------- 基本参数 ----------------
nPop      = 50;
dim       = 20;                  % CEC-2022: 2/10/20
Max_iter  = (10000*dim)/nPop;
run_times = 20;                  % 独立试验次数

AlgorithmList = {'DE','IKUN-DE','JADE','IKUN-JADE','GA','IKUN-GA'};
AlgorithmFunc = {@DE,@IKUN_DE,@JADE,@IKUN_JADE,@GA,@IKUN_GA};

%% ---------------- 主循环 ----------------
for funID = 1:12
    [lb,ub,~,fobj] = Get_Functions_cec2022(funID,dim);

    % 结果容器：1 name | 2 curve | 3 bestVal | 4 bestPos
    Opt = cell(4,numel(AlgorithmList));
    Opt(1,:) = AlgorithmList;
    timeRec  = zeros(run_times,numel(AlgorithmList));

    for rID = 1:run_times
        for alg = 1:numel(AlgorithmList)
            tic
            [bestScore,bestPos,curve] = AlgorithmFunc{alg}( ...
                                    nPop,Max_iter,lb,ub,dim,fobj);
            timeRec(rID,alg)   = toc;

            Opt{2,alg}(rID,:)  = curve;
            Opt{3,alg}(rID,1)  = bestScore;
            Opt{4,alg}(rID,:)  = bestPos;

            fprintf('F%02d  run%02d  %-9s  best=%.3e  time=%.2fs\n', ...
                    funID,rID,AlgorithmList{alg},bestScore,timeRec(rID,alg));
        end
    end

    %% ---------- 统计指标 ----------
    [Res,Wilc,Fried] = Cal_stats_dif(Opt,timeRec);
    fileName = sprintf('cec2022_Results_D%d.xlsx',dim);

    %% ---------- Sheet-1: 指标 + 平均时间 ----------
    metrics = Res(3:7,:);      % {worst,best,std,mean,time}
    rowLab  = {'worst';'best';'std';'mean';'time'};
    blk     = [rowLab, metrics];
    startR  = (funID-1)*5 + 2;

    xlswrite(fileName, AlgorithmList , 1 , 'C1');
    xlswrite(fileName, {['F' num2str(funID)]}, 1, sprintf('A%d',startR));
    xlswrite(fileName, blk, 1, sprintf('B%d',startR));

    %% ---------- Sheet-2: Wilcoxon ----------
    % 仅输出 3 组比较结果：DE↔IKUN-DE，SHADE↔IKUN-SHADE，GA↔IKUN-GA
    xlswrite(fileName, {'IKUN-DE','IKUN-SHADE','IKUN-GA'}, 2, 'C1');
    wHead = {['F' num2str(funID)];''};          % 两行：符号秩 & 秩和
    wVal  = num2cell([Wilc.signed ; Wilc.ranksum]);  % 2×3
    xlswrite(fileName, [wHead wVal], 2, sprintf('A%d',(funID-1)*2+2));

    %% ---------- Sheet-3: Friedman ----------
    xlswrite(fileName, {['F' num2str(funID)],'Friedman',Fried}, ...
                       3, sprintf('A%d',funID+1));

    %% ---------- Sheet-4: 每次运行时间 ----------
    xlswrite(fileName, AlgorithmList, 4, 'B1');
    tStart = (funID-1)*run_times + 2;
    xlswrite(fileName, [[{['F' num2str(funID)]}; cell(run_times-1,1)] ...
                        num2cell(timeRec)], 4, sprintf('A%d',tStart));
        %% 绘图（函数图像与收敛曲线）
    color_mat = hsv(length(AlgorithmList));
    figure('name',['F' num2str(funID) ' 函数图像 & 收敛曲线'])
    
    subplot(1,2,1)
    func_plot_cec2022(funID,dim)
    colormap(cool)

    subplot(1,2,2)
    for i = 1:length(AlgorithmList)
        semilogy(mean(Opt{2,i}),...
            'LineWidth',1.5,'Color',color_mat(i,:));
        hold on
    end
    title(['Convergence curve, Dim=' num2str(dim)])
    xlabel('Iteration'); ylabel('Best Fitness');
    legend(AlgorithmList); grid on; box on
    saveas(gcf, ['cec2022-F' num2str(funID) '收敛图.png']); 
    close(gcf);

    %% 箱线图
    figure('name',['F' num2str(funID) ' 箱线图'],'Position',[400 200 300 180])
    boxplot_mat = [];
    for i = 1:length(AlgorithmList)
        boxplot_mat = [boxplot_mat, Opt{3,i}];
    end
    boxplot(boxplot_mat,'Labels',AlgorithmList)
    ylabel('Best Fitness');
    title(['cec2022-F' num2str(funID)])
    saveas(gcf, ['cec2022-F' num2str(funID) '箱线图.png']);
    close(gcf);
end
