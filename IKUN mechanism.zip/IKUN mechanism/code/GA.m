function [gBestScore, gBest, cg_curve] = GA(N, Max_iteration, lb, ub, dim, fobj)
% -------------------------------------------------------------------------
% A canonical (µ+λ) Genetic Algorithm for the CEC-2022 benchmark.
%
% INPUT
%   N              – population size  (µ = λ = N)
%   Max_iteration  – number of generations
%   lb, ub         – 1×dim vectors with lower / upper bounds
%   dim            – search–space dimensionality (2 / 10 / 20 for CEC-2022)
%   fobj           – function handle,   f = fobj(x) ,   x is 1×dim row‐vector
%
% OUTPUT
%   gBestScore     – best objective value found
%   gBest          – 1×dim vector, best position
%   cg_curve       – 1×Max_iteration vector, convergence trace
%
% GA settings follow Section \ref{sec:setup} of the manuscript:
%   • two-point crossover,   p_c = 0.9
%   • bit-flip mutation,     p_m = 1/dim (independent per gene)
%   • elitist (µ+λ) reinsertion of the best N individuals
% -------------------------------------------------------------------------

% ----- GA hyper-parameters ------------------------------------------------
p_c = 0.9;                  % crossover probability
p_m = 1 / dim;              % per-gene mutation probability
popSize = N;                % µ = λ

% ----- Initialise population ---------------------------------------------
pop  = initialization(popSize, dim, ub, lb);          % µ individuals
fit  = arrayfun(@(row) fobj(pop(row, :)), 1:popSize)';% column vector

% ----- Best-so-far record -------------------------------------------------
[gBestScore, bestIdx] = min(fit);
gBest                = pop(bestIdx, :);
cg_curve             = zeros(1, Max_iteration);

% ========== Evolutionary loop ==========
for gen = 1:Max_iteration
    
    % -------- Parent selection (roulette wheel, minimisation) ------------
    fitnessInv = 1 ./ (fit + eps);          % avoid division by zero
    prob       = fitnessInv / sum(fitnessInv);
    cumProb    = cumsum(prob);
    
    parentsIdx = zeros(popSize, 1);
    for i = 1:popSize
        r = rand;
        parentsIdx(i) = find(cumProb >= r, 1, 'first');
    end
    parents = pop(parentsIdx, :);
    
    % -------- Variation: crossover + mutation ----------------------------
    offspring = zeros(popSize, dim);
    for i = 1:2:popSize
        % select a second parent (wrap around if necessary)
        j = i + 1;
        if j > popSize, j = 1; end
        
        p1 = parents(i, :);
        p2 = parents(j, :);
        
        % Two-point crossover
        if rand < p_c
            cutPoints = sort(randi([1, dim-1], 1, 2));  % two distinct cuts
            c1 = p1; c2 = p2;
            c1(cutPoints(1):cutPoints(2)) = p2(cutPoints(1):cutPoints(2));
            c2(cutPoints(1):cutPoints(2)) = p1(cutPoints(1):cutPoints(2));
        else
            c1 = p1; c2 = p2;   % no crossover
        end
        
        offspring(i, :) = c1;
        offspring(j, :) = c2;
    end
    
    % Bit-flip mutation (uniform re-sampling within bounds)
    mutationMask = rand(popSize, dim) < p_m;
    randPart     = bsxfun(@plus, lb, rand(popSize, dim) .* (ub - lb));
    offspring(mutationMask) = randPart(mutationMask);
    
    % -------- Bound handling ---------------------------------------------
    offspring = min(max(offspring, lb), ub);
    
    % -------- Evaluate offspring -----------------------------------------
    offFit = arrayfun(@(row) fobj(offspring(row, :)), 1:popSize)';  
    
    % -------- (µ+λ) survivor selection -----------------------------------
    unionPop = [pop ; offspring];
    unionFit = [fit ; offFit];
    
    [~, sortIdx] = sort(unionFit, 'ascend');         % minimisation
    pop = unionPop(sortIdx(1:popSize), :);
    fit = unionFit(sortIdx(1:popSize));
    
    % -------- Update global best -----------------------------------------
    if fit(1) < gBestScore
        gBestScore = fit(1);
        gBest      = pop(1, :);
    end
    
    cg_curve(gen) = gBestScore;
end
end
