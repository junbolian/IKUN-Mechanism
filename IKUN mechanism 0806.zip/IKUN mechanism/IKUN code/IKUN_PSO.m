function [gBestScore, gBest, cg_curve] = IKUN_PSO(N, Max_iteration, lb, ub, dim, fobj)
    % IKUN-enhanced Particle Swarm Optimization

    %% PSO Parameters
    Vmax = 2;
    noP = N;
    wMax = 0.9;
    wMin = 0.2;
    c1 = 2;
    c2 = 2;

    %% IKUN Parameters
    k = 7; %(3,5,7,10)
    lambda = 0.5; %(0.01,0.1,0.3,0.5,1)
    W = 5;          % Window size (generations kept in memory) (3,4,5)

    %% Initialization
    iter = Max_iteration;
    vel = zeros(noP, dim);
    pos = initialization(noP, dim, ub, lb); 

    pBestScore = inf(noP, 1);
    pBest = zeros(noP, dim);
    gBest = zeros(1, dim);
    cg_curve = zeros(1, iter);
    gBestScore = inf;

    % Persistent memory of historical positions
    persistent HistoryPositions KDtree

    HistoryPositions = [];
    KDtree = [];

    for l = 1:iter
        % Update density / crowding potential
        [U, HistoryPositions, KDtree] = IKUN(pos, l, W, k, HistoryPositions, KDtree);

        for i = 1:noP
            % Boundary handling
            pos(i,:) = max(min(pos(i,:), ub), lb);

            % Objective evaluation
            fitness = fobj(pos(i,:)) + lambda * U(i);  % Augmented cost
            raw_fit = fobj(pos(i,:));                 % Record true fitness

            % Update personal best
            if pBestScore(i) > raw_fit
                pBestScore(i) = raw_fit;
                pBest(i, :) = pos(i, :);
            end

            % Update global best
            if gBestScore > raw_fit
                gBestScore = raw_fit;
                gBest = pos(i, :);
            end
        end

        % PSO inertia weight decay
        w = wMax - l * ((wMax - wMin) / iter);

        % Velocity & position update (with repulsion from crowding)
        for i = 1:noP
            for j = 1:dim
                vel(i,j) = w * vel(i,j) ...
                    + c1 * rand() * (pBest(i,j) - pos(i,j)) ...
                    + c2 * rand() * (gBest(j) - pos(i,j));

                % Velocity clamping
                vel(i,j) = max(min(vel(i,j), Vmax), -Vmax);

                pos(i,j) = pos(i,j) + vel(i,j);
            end
        end

        cg_curve(l) = gBestScore;
    end
end