function [gBestScore, gBest, cg_curve] = IKUN_GA(N, Max_iteration, lb, ub, ...
                                                dim, fobj)
% -------------------------------------------------------------------------
% IKUN-enhanced Genetic Algorithm (µ+λ GA) for CEC-2022 functions.
%
% The code augments a canonical GA with the IKUN crowd-repulsion mechanism
% described in Section 2.  Density is estimated from a sliding window of the
% W most-recent generations via a KD-tree; the resulting potential U is
% linearly weighted by λ and added to the objective when selecting parents
% or survivors.
%
% INPUT
%   N, Max_iteration, lb / ub, dim, fobj  –– as in GA(…)
%   k        – number of nearest neighbours (e.g., 7)
%   lambda   – crowding coefficient        (e.g., 0.5)
%   W        – window size (generations)   (e.g., 5)
%
% OUTPUT     – identical to GA(…)
% -------------------------------------------------------------------------
    %% IKUN Parameters
    k = 5; %(3,5,7,10)
    lambda = 0.3; %(0.01,0.1,0.3,0.5,1)
    W = 5;          % Window size (generations kept in memory) (3,4,5)
%% GA hyper-parameters (Section \ref{sec:setup})
p_c = 0.9;                 % two-point crossover probability
p_m = 1 / dim;             % bit-flip mutation probability
popSize = N;               % µ = λ

%% Initialise population and persistent IKUN memory
pop  = initialization(popSize, dim, ub, lb);
fit  = arrayfun(@(row) fobj(pop(row ,:)), 1:popSize)';  % N×1 column

persistent HistoryPositions KDtree                     % IKUN memory
HistoryPositions = []; KDtree = [];

[U, HistoryPositions, KDtree] = IKUN(pop, 1, W, k, ...
                                     HistoryPositions, KDtree);
F_aug = fit + lambda * U;                              % augmented cost

[gBestScore, idx] = min(fit);
gBest              = pop(idx ,:);
cg_curve           = zeros(1, Max_iteration);

%% ========== Evolution loop ==========
for gen = 1:Max_iteration
    
    % ------------- Parent selection (roulette on 1/F_aug) ----------------
    prob    = 1 ./ (F_aug + eps);        prob = prob / sum(prob);
    cumProb = cumsum(prob);
    
    parentsIdx = arrayfun(@(~) find(cumProb >= rand, 1), 1:popSize);
    parents    = pop(parentsIdx ,:);
    
    % ------------- Variation --------------------------------------------
    offspring = zeros(popSize , dim);
    for i = 1:2:popSize
        j = i + 1;  if j > popSize, j = 1; end
        p1 = parents(i ,:);   p2 = parents(j ,:);
        
        % two-point crossover
        if rand < p_c
            cuts = sort( randi([1, dim-1], 1, 2) );
            o1 = p1; o2 = p2;
            o1(cuts(1):cuts(2)) = p2(cuts(1):cuts(2));
            o2(cuts(1):cuts(2)) = p1(cuts(1):cuts(2));
        else
            o1 = p1;  o2 = p2;
        end
        
        offspring(i ,:) = o1;
        offspring(j ,:) = o2;
    end
    
    % bit-flip mutation (uniform resampling within bounds)
    mMask = rand(popSize, dim) < p_m;
    randPart = lb + rand(popSize, dim) .* (ub - lb);
    offspring(mMask) = randPart(mMask);
    
    % bound handling
    offspring = min(max(offspring, lb), ub);
    
    % ------------- Evaluate offspring and IKUN potential -----------------
    offFit = arrayfun(@(row) fobj(offspring(row ,:)), 1:popSize)';
    
    [U_off, HistoryPositions, KDtree] = IKUN(offspring, gen+1, W, k, ...
                                             HistoryPositions, KDtree);
    F_off = offFit + lambda * U_off;
    
    % ------------- (µ+λ) elitist reinsertion -----------------------------
    unionPop  = [pop ; offspring];
    unionFit  = [fit ; offFit];
    unionFaug = [F_aug ; F_off];
    
    [~, ord]  = sort(unionFaug , 'ascend');          % minim. augmented cost
    pop       = unionPop(ord(1:popSize) ,:);
    fit       = unionFit(ord(1:popSize));
    F_aug     = unionFaug(ord(1:popSize));
    
    % ------------- Global best (true objective) --------------------------
    [bestGen, idx] = min(fit);
    if bestGen < gBestScore
        gBestScore = bestGen;
        gBest      = pop(idx ,:);
    end
    cg_curve(gen) = gBestScore;
end
end
