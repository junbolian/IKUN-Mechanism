function [fitnessBestP,bestP,Convergence_curve] = IKUN_JADE( ...
          SearchAgents_no, Gmax, lb, ub, dim, fobj)
    %% IKUN Parameters
    k = 5; %(3,5,7,10)
    lambda = 0.3; %(0.01,0.1,0.3,0.5,1)
    W = 5;          % Window size (generations kept in memory) (3,4,5)
% ---------------- 默认 IKUN 参数 ----------------
if nargin<7,  lambda = 0.50; end     % crowding coefficient
if nargin<8,  k      = 7;    end     % k-NN
if nargin<9,  W      = 5;    end     % window size
% ------------------------------------------------
if max(size(ub))==1,  ub=ub.*ones(1,dim); lb=lb.*ones(1,dim);  end
lu = [lb;ub];

%% ---------- JADE 固有初始化 ----------
c  = 1/10;  p = 0.05;
uCR = 0.5;  uF  = 0.5;
A   = [];   tA  = 0;
G   = 0;

% 种群
P = repmat(lb,SearchAgents_no,1) + ...
    rand(SearchAgents_no,dim).*repmat((ub-lb),SearchAgents_no,1);
fitnessP = arrayfun(@(i) fobj(P(i,:)), 1:SearchAgents_no);
[fitnessBestP,idx] = min(fitnessP); bestP = P(idx,:);
Convergence_curve  = zeros(Gmax,1);

%% ---------- IKUN 额外状态 ----------
HistoryPos = P;                    % 最近 W 代的轨迹
KDtree     = createns(HistoryPos,'NSMethod','kdtree');

%% ---------- 主循环 ----------
while G < Gmax
    G = G + 1;
    top = max(1,round(p*SearchAgents_no));
    [~,idxSort] = sort(fitnessP);      % 当前 fitness 排序
    bestTopP    = P(idxSort(1:top),:); % p-best 集

    % --- 自适应 F/CR 生成 ---
    CR = normrnd(uCR,0.1,[SearchAgents_no,1]);
    CR = min(max(CR,0),1);
    F  = cauchyrnd(uF,0.1,[SearchAgents_no,1]);
    F(F>1)=1;  F(F<=0)=uF;

    Scr = []; Sf = [];   % 成功参数池
    for i = 1:SearchAgents_no
        % ---------- 变异 ----------
        Xpbest = bestTopP(randi(top),:);
        r1 = i;    while r1==i, r1=randi(SearchAgents_no); end
        unionPA   = [P;A];
        r2 = i;
        while r2==i || r2==r1,  r2=randi(size(unionPA,1)); end

        V = P(i,:) + F(i).*(Xpbest-P(i,:)) ...
                  + F(i).*(P(r1,:)-unionPA(r2,:));

        % ---------- 交叉 ----------
        jrand = randi(dim);
        U = P(i,:);
        crossMask = rand(1,dim) < CR(i);  crossMask(jrand)=true;
        U(crossMask) = V(crossMask);

        % ---------- 边界处理 ----------
        U = max(U,lb);  U = min(U,ub);

        % ---------- IKUN: crowding potential ----------
        % trial 与 parent 的密度
        U_rho = crowding_density(U,      KDtree,k);
        X_rho = crowding_density(P(i,:), KDtree,k);
        F_aug_new = fobj(U)     + lambda*U_rho;
        F_aug_old = fitnessP(i) + lambda*X_rho;

        % ---------- 选择 ----------
        if F_aug_new < F_aug_old - 1e-12
            accept = true;
        elseif abs(F_aug_new - F_aug_old) < 1e-12 && U_rho < X_rho
            accept = true;
        else
            accept = false;
        end

        if accept
            A = [A; P(i,:)]; tA = tA+1;
            if tA > SearchAgents_no           % 控制归档大小
                A( randi(tA), : ) = [];  tA = tA-1;
            end
            P(i,:)     = U;
            fitnessP(i)= fobj(U);

            Scr = [Scr; CR(i)];
            Sf  = [Sf;  F(i)];
        end
    end

    % ---------- 自适应参数更新 ----------
    if ~isempty(Scr)
        w   = (Sf.^2)./Sf;  w = w./sum(w);
        uCR = (1-c)*uCR + c*sum(w.*Scr);
        uF  = (1-c)*uF  + c*sum(w.*Sf);
    end

    % ---------- IKUN: 维护滑窗 KD-tree ----------
    HistoryPos = [HistoryPos; P];
    if size(HistoryPos,1) > W*SearchAgents_no
        HistoryPos(1:SearchAgents_no,:) = [];  % 删最早一代
    end
    if mod(G,W)==1        % 每 W 代重建一次
        KDtree = createns(HistoryPos,'NSMethod','kdtree');
    end

    % ---------- 记录 ----------
    [fitnessBestP,idx] = min(fitnessP);
    bestP = P(idx,:);
    Convergence_curve(G) = fitnessBestP;
end
Convergence_curve=Convergence_curve(1:G);

end   % ------- IKUN_JADE 结束 -------


% ================ 工具函数 ======================
function rho = crowding_density(X, KDtree, k)
%  X 可以是 1×D 或 N×D
[~,dist] = knnsearch(KDtree,X,'K',k+1);   % 包含自己
dist = dist(:,2:end);
rho  = 1 ./ (mean(dist,2)+eps);
end

function r = cauchyrnd(mu,gamma,varargin)
% 简易 Cauchy 随机数
u = rand(varargin{:})-0.5;
r = mu + gamma*tan(pi*u);
end
