function [U, HistoryPositions, KDtree] = IKUN(pos, iter, W, k, HistoryPositions, KDtree)
    % IKUN module: estimates density using KD-tree over sliding window
    % Inputs:
    %   pos: N x dim
    %   iter: current iteration
    %   W: window size
    %   k: number of neighbors
    %   HistoryPositions: previous memory
    % Outputs:
    %   U: N x 1 vector of crowding potentials

    % Update history
    HistoryPositions = [HistoryPositions; pos];
    maxPoints = size(pos,1) * W;
    if size(HistoryPositions,1) > maxPoints
        HistoryPositions(1:end-size(pos,1),:) = []; % keep W generations
    end

    % Periodic rebuild of KD-tree
    if mod(iter,W) == 1 || isempty(KDtree)
        KDtree = createns(HistoryPositions, 'NSMethod', 'kdtree');
    end

    % Density estimation via mean distance to k nearest neighbors
    [~, Dist] = knnsearch(KDtree, pos, 'K', k+1); % include itself
    Dist = Dist(:, 2:end); % exclude self
    Density = 1 ./ (mean(Dist, 2) + eps); % avoid divide-by-zero

    U = Density; % use density directly as crowding potential
end